import { mysqlTable, serial, varchar } from "drizzle-orm/mysql-core"


export const urlShortnerTable = mysqlTable("urlShortner",{
    id:serial().primaryKey(),
    url:varchar({length:255}).notNull(),
    shortcode:varchar({length:255}).notNull().unique()
})  

