import { Header } from "./Header/Header";
import { Outlet } from "react-router-dom";
import "./main-layout.css";
import { Sidebar } from "./Sidebar/Sidebar";

export const MainLayout = () => {
  return (
    <>
      <header>
        <Header />
      </header>

      <div className="content-area">
        <Sidebar />

        <main>
          <Outlet />
        </main>
      </div>


    </>
  );
};
