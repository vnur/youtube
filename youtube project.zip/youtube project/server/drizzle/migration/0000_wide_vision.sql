CREATE TABLE `urlShortner` (
	`id` serial AUTO_INCREMENT NOT NULL,
	`url` varchar(255) NOT NULL,
	`shortcode` varchar(255) NOT NULL,
	CONSTRAINT `urlShortner_id` PRIMARY KEY(`id`),
	CONSTRAINT `urlShortner_shortcode_unique` UNIQUE(`shortcode`)
);
