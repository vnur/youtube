import { createData, getData } from "../services/urlshortener.service.js";
import crypto from "crypto";



export const getHomePage = (req, res) => {
  return res.render("index");
};

export const postHomePage = async (req, res) => {
  const { url, shortcode } = req.body;

  const link = await getData(shortcode);
  if (!url) {
    res.status(500).status("url is not provided please provide the url");
  }

  const finalShortCode = shortcode || crypto.randomBytes(4).toString("hex");

  if (!link) {
    await createData({url,shortcode:finalShortCode})
  }

  res.status(200).send({ shortcode, url });
};
