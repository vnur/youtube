import { eq } from "drizzle-orm";
import { DB } from "../config/db.js";
import { urlShortnerTable } from "../drizzle/schema.js";

export const getData = async (shortcode) => {
  const [data] =await DB.select()
    .from(urlShortnerTable)
    .where(eq(shortcode, shortcode));
    return data
};

export const createData =async ({url,shortcode})=>{
  console.log(url, shortcode);
  
  return await DB.insert(urlShortnerTable).values({url:url, shortcode:shortcode})
}