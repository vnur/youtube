import { useInfiniteQuery, useQueryClient } from "@tanstack/react-query";
import { useSearchParams } from "react-router-dom";
import { youtubeFetchData } from "../../api/YoutubeApi";
import { VideoCard } from "../../components/ui/VideoCard/VideoCard";
import { useEffect } from "react";
import { useInView } from "react-intersection-observer";

export const SearchPage = () => {
  const [searchquery] = useSearchParams();
  const query = searchquery.get("search_query");



  

  const { inView, ref } = useInView({
    threshold: 1,
  });



  const { data, hasNextPage, fetchNextPage, isFetchingNextPage } = useInfiniteQuery({
    queryKey: ["youtube-data", query],
    queryFn: youtubeFetchData,
    getNextPageParam: (lastpage) => {
      return lastpage.nextPageToken ?? undefined;
    },
  });
  useEffect(() => {
    if (inView && hasNextPage) {
      fetchNextPage();
    }
  }, [inView,hasNextPage, fetchNextPage]);

  return (
    <div>
      <VideoCard searchData={data} layout="search"      ref={ref} isFetchingNextPage={isFetchingNextPage} hasNextPage={hasNextPage} />
    </div>
  );
};
