import "./homepage.css";
import { HomePageContentsPoints } from "./home-page-content-points/HomePageContentPoints";
import { HomePageVideoList } from "./home-page-video-list/HomePageVideoList";

export const HomePage = () => {
  return (
    <div className="home-page__container">
      <HomePageContentsPoints />
      <HomePageVideoList />
    </div>
  );
};
