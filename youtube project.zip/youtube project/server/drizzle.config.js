import {defineConfig} from "drizzle-kit"


export default defineConfig({
    dialect:"mysql",
    out:"./drizzle/migration",
    schema:"./drizzle/schema.js",
    dbCredentials:{
        url:process.env.DATABASE_URL
    }
})