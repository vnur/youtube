import { CiSearch } from "react-icons/ci";
import { FaMicrophone } from "react-icons/fa";
import "./navbar-search.css";
import { NavbarSearchList } from "./NavbarSearchList/NavbarSearchList";
import { useInputSearch } from "../../../../context/InputSearchContext";
import { useState } from "react";

export const NavbarSearch = () => {
  const { searchQuery, setSearchQuery, searchList, setSearchList } =useInputSearch();
  const [inputFocus,setInputFocus ]=useState(false)

  return (
    <>
      <li className="navbar-search">
        <div className="navbar-search__searchpage">
              
          <div className="navbar-search__inputsearchblock" >
            <input
              className="navbar-search__input"
              type="text"
              placeholder="Search"
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setSearchList(true);
              }}
              onBlur={()=>setTimeout(()=>{setInputFocus(false)},400)}

              onFocus={()=>{setInputFocus(true)}}
              value={searchQuery}
            />
            <button className="navbar-search__searchButtons">
              <CiSearch />
            </button>

            {inputFocus &&  searchQuery && searchList && (<NavbarSearchList  />)}
          </div>

          <button className="navbar-search__micButton">
            <FaMicrophone />
          </button>
        </div>
      </li>
    </>
  );
};
