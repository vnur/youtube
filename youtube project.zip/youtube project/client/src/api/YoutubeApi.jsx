  import axios from "axios";

  const baseURL = "https://www.googleapis.com/youtube/v3";

  export const youtubeFetchData = async ({ pageParam = "", queryKey }) => {
    const [, searchValueData] = queryKey;

    const searchData = await axios.get(`${baseURL}/search`, {
      params: {
        key: import.meta.env.VITE_YT_API_KEY,
        part: "snippet",
        q: searchValueData,
        type: "video",
        regionCode: "IN",
        maxResults: 2,
        pageToken: pageParam,
      },
    });

    const alldata = searchData.data.items.map(async (item) => {
      const channelData = await axios.get(`${baseURL}/channels`, {
        params: {


          
          key: import.meta.env.VITE_YT_API_KEY,
          part: "snippet",
          id: item.snippet.channelId,
        },
      });
      return {
        videoId:item.id.videoId,
        // videoUrl:`https://www.youtube.com/watch?v=${item.id.videoId}`,
        videoUrl:`https://www.youtube.com/embed/${item.id.videoId}`,
        videoTitle:item.snippet.title,
        videoThumbnail:item.snippet.thumbnails.high.url,
        channelTitle:item.snippet.channelTitle,
        channelThumbnail:channelData.data.items[0].snippet.thumbnails.high.url,
      }
    });
    const datapromise =await Promise.all(alldata)
    return{
      nextPageToken:searchData.data.nextPageToken,
      youtubeData:datapromise
    }
    
  };
