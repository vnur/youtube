import "./navbar-auth.css"

export const NavbarAuth = ()=>{
     return(
        <div>navbar auth works</div>
     )
}