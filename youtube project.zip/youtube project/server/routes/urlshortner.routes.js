import {Router} from "express"
import * as urlshortner from "../controllers/urlshortner.controller.js"
const router = Router()


router.route("/").get(urlshortner.getHomePage).post(urlshortner.postHomePage)

export const routes = router