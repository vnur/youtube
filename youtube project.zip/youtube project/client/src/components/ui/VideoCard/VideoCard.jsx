import { Link } from "react-router-dom";
import "./video-card.css";

export const VideoCard = ({
  videoData,
  layout,
  searchData,
  ref,
  isFetchingNextPage,
  hasNextPage,
}) => {
  const selectedData = layout === "home" ? videoData : searchData;

  return (
    <>
      {selectedData?.pages
        .flatMap((item) => item.youtubeData)
        .map((item) => {
          return (
            <Link
              to={`/videopage/${item.videoId}`}
              key={item.videoId}
              className={
                layout == "home" ? "video-card__home" : "video-card__search"
              }
            >
              <div className="video__image">
                <img src={item.videoThumbnail} alt={item.videoTitle} />
              </div>

              <div className="video__description">
                <div>
                  <img src={item.channelThumbnail} alt={item.vid} />
                </div>
                <div className="video__description__right">
                  <div>{item.videoTitle}</div>
                  <div>{item.channelTitle}</div>
                </div>
              </div>
            </Link>
          );
        })}
      <div ref={ref} style={{ textAlign: "center" }}>
        {isFetchingNextPage
          ? "Loading More"
          : hasNextPage
          ? "Scroll Down to next Page"
          : "No more Content"}
      </div>
    </>
  );
};
