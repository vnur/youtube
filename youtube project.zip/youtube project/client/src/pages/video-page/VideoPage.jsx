import { useParams } from "react-router-dom";
import "./video-page.css";
import { useQuery } from "@tanstack/react-query";
import { youtubeFetchData } from "../../api/YoutubeApi";
import { useEffect } from "react";

export const VideoPage = () => {
  const { videoPageId } = useParams();

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ["youtube-video", videoPageId],
    queryFn: youtubeFetchData,
  });

  if (isError) {
    return <h1>{error.message}</h1>;
  }

  if (isLoading) {
    return <h1>Loading....</h1>;
  }

  const matchedVideo = data?.youtubeData?.find(
    (video) => video.videoId === videoPageId
  );
  console.log(matchedVideo.videoUrl);

  return (
    <div className="video-page__container">
      <h1>Video Page Here</h1>
      {matchedVideo ? (
        <iframe
          src={matchedVideo.videoUrl}
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          width="600"
          height="600"
          title={matchedVideo.videoTitle}
        X-Frame-Options="sameorigin"
        />
      ) : (
        "No Videos Found"
      )}
    </div>
  );
};
