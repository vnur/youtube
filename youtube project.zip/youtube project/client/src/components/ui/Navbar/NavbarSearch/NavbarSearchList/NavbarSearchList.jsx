import { CiSearch } from "react-icons/ci";
import "./navbar-search-list.css";
import { useEffect, useState } from "react";
import { youtubeFetchData } from "../../../../../api/YoutubeApi";
import { useInputSearch } from "../../../../../context/InputSearchContext";
import { Link } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";

export const NavbarSearchList = () => {
  const { searchQuery } = useInputSearch();
  const [debouncing, setDebouncing] = useState("");
  const [Ydata, setYdata] = useState([]);
  const queryClient = useQueryClient();

  //when the input change the after few second we store the data in the debouncing using the setdebouncing
  useEffect(() => {
    const timer = setTimeout(() => {
      setDebouncing(searchQuery);
    }, 500);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  //based on the changes in the debouncing results we call the api
  useEffect(() => {
    const fetchListData = async () => {
      try {
        const res = await youtubeFetchData({
          queryKey: ["youtube-video", debouncing],
        });
        setYdata(res.youtubeData);

        queryClient.setQueryData(
          ["youtube-video", debouncing],
          res.youtubeData
        );
      } catch (error) {
        console.log("error getting list data", error);
      }
    };
    if (debouncing) {
      fetchListData();
    }
  }, [debouncing]);

  

  return (
    <div className="navbar-search-list__container">
      {debouncing && Ydata.map((item, index) => {
        const { videoTitle } = item;
        return (  
            <Link key={index} to={`/results?search_query=${debouncing.trim().replace(/\s+/g,"+")}`}>
              <div  className="navbar-search-list__block">
                <CiSearch />

                <p>{`${videoTitle.slice(0, 30)}...`}</p>
              </div>
            </Link>
          )
        
      })}


    </div>
  );
};
