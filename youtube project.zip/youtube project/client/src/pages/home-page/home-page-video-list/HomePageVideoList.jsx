import "./home-page-video-list.css";
import { youtubeFetchData } from "../../../api/YoutubeApi";
import { useInfiniteQuery } from "@tanstack/react-query";
import { useEffect } from "react";
import { VideoCard } from "../../../components/ui/VideoCard/VideoCard";
import { useSidebarToggleContext } from "../../../context/SidebarToggleContext";

export const HomePageVideoList = () => {
    const { toggleSideBar } = useSidebarToggleContext();
  
  const { data, hasNextPage, fetchNextPage, isLoading, isError, error } =
    useInfiniteQuery({
      queryKey: ["youtube-video"],
      queryFn: youtubeFetchData,
      getNextPageParam: (lastpage) => {
        return lastpage.nextPageToken ?? undefined;
      },
      refetchInterval: false,
      refetchOnWindowFocus: false,
      staleTime: Infinity,
    });

    
  const handleScroll = () => {
    const bottom =
      window.innerHeight + window.scrollY >=
      document.documentElement.scrollHeight - 1;
    if (bottom && hasNextPage) {
      fetchNextPage();
    }
  };

  useEffect(() => {
    window.addEventListener("scroll", handleScroll);
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, [hasNextPage, fetchNextPage]);

  if (isLoading) {
    return (<div>loading ...</div>);
  }

  if (isError) {
    return (<div>{error.message}</div>);
  }

  return (
    <div className={`home-page-video-list__container ${toggleSideBar ? 'maxHomePageWidth': ""}` }>
      <VideoCard videoData={data} layout="home" />
    </div>
  );
};
