import { createBrowserRouter } from "react-router-dom";
import { MainLayout } from "../components/layout/MainLayout/MainLayout";
import { HomePage } from "../pages/home-page/HomePage";
import { ErrorPage } from "../pages/error-page/ErrorPage";
import { VideoPage } from "../pages/video-page/VideoPage";
import { SearchPage } from "../pages/search-page/SearchPage";

export const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    errorElement: <ErrorPage />,
    children: [
      {
        path: "/",
        element: <HomePage />,
      },

      {
        path: "/results",
        element: <SearchPage />,
      },

      {
        path: "/videopage/:videoPageId",
        element: <VideoPage />,
      },
      
    ],
  },
]);
