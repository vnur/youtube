import "./navbar-left.css";
import { useSidebarToggleContext } from "../../../../context/SidebarToggleContext";
import { FiMenu } from "react-icons/fi";

export const NavbarLeft = () => {
  const {setToggleSideBarFun}= useSidebarToggleContext()
  

  return (
    <li className="navbar-left">
      <FiMenu onClick={setToggleSideBarFun} />

      <div className="navbar-left__youtubetxtimg">
        <img className="navbar-left__youtubeimg" width="20px" src="youtube.png" alt="" />

        <div className="navbar-left__youtubetxt">
          YouTube <sup>vinu</sup>
        </div>
      </div>
    </li>
  );
};
